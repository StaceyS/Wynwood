(function($){
	$(document).ready(function(){
		$('body').addClass('js').removeClass('no-js');
	});
})(jQuery);
